# # from opencd.apis import OpenCDInferencer
# # # Load models into memory
# # inferencer = OpenCDInferencer(model='/home/f523/disk2/nym/open-cd-main/work_dirs/1112-2/changeformer_mit-b1_256x256_40k_levircd.py', weights='/home/f523/disk2/nym/open-cd-main/work_dirs/1112-2/best_mIoU_iter_1000.pth', classes=('unchanged', 'changed'), palette=[[0, 0, 0], [255, 255, 255]])
# # # Inference
# # inferencer([['/home/f523/disk2/nym/open-cd-main/data/cdd/infer/0-2_small-hkj-CRH380AL-20250903001-2920-00-52dao-3_1-fixed-2-area48-2-c4500-r1250.jpg', '/home/f523/disk2/nym/open-cd-main/0-1_CRH380AL-3_16-fixed-1-area48-2-c4500-r1250.jpg']], show=False, out_dir='OUTPUT_PATH_1112/test-3/12')
#
# from opencd.apis import OpenCDInferencer
# import os
# import shutil
#
# # 1. 初始化推理器
# inferencer = OpenCDInferencer(
#     model='/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/train_638.png',
#     weights='/home/f523/disk2/nym/open-cd-main/work_dirs/JQR/iter_5000.pth',
#     classes=('unchanged', 'changed'),
#     palette=[[0, 0, 0], [255, 255, 255]]
# )
#
# image_pairs = [
#     [
#         '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/train_638.png',
#         '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/train_638.png'
#     ],
#     [
#         '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/train_639.png',
#         '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/train_639.png'
#     ]
# ]
#
# # 执行推理（自动循环处理）
# #inferencer(image_pairs, show=False, out_dir='OUTPUT_PATH_1112/test-33')
# # for i, pair in enumerate(image_pairs):
# #     inferencer([pair], show=False, out_dir=f'OUTPUT_PATH_1112/test-5/{i:02d}_result')
# # 3. 统一输出目录（只保存 vis 结果）
# final_out_dir = 'OUTPUT_PATH_0423/sh/vis_results'
# os.makedirs(final_out_dir, exist_ok=True)
#
# # 4. 执行批量推理
# for i, pair in enumerate(image_pairs):
#     print(f'🔹 正在处理第 {i+1}/{len(image_pairs)} 组：{os.path.basename(pair[0])}')
#
#     # 每组使用单独的临时目录
#     temp_out_dir = f'OUTPUT_PATH_0423/sh/_temp_{i}'
#     os.makedirs(temp_out_dir, exist_ok=True)
#
#     # 执行推理
#     inferencer([pair], show=False, out_dir=temp_out_dir)
#
#     # vis 目录路径
#     vis_dir = os.path.join(temp_out_dir, 'vis')
#
#     # 如果存在 vis 结果，则拷贝出来并重命名
#     if os.path.exists(vis_dir):
#         for f in os.listdir(vis_dir):
#             src = os.path.join(vis_dir, f)
#             # 用第一张图片命名输出结果（保持原扩展名）
#             base_name = os.path.splitext(os.path.basename(pair[0]))[0]
#             ext = os.path.splitext(f)[1] or '.png'
#             dst = os.path.join(final_out_dir, f"{base_name}{ext}")
#             shutil.copy(src, dst)
#             print(f'✅ 已保存可视化结果: {dst}')
#     else:
#         print(f'⚠️ 未找到 vis 结果：{vis_dir}')
#
#     # 删除整个临时目录
#     shutil.rmtree(temp_out_dir, ignore_errors=True)
#
# print(f'\n🎉 全部完成！共输出 {len(image_pairs)} 张 vis 结果到：{final_out_dir}')

from opencd.apis import OpenCDInferencer
import os
import shutil
import cv2
import numpy as np

# ==============================
# 1. 初始化推理器
# ==============================
inferencer = OpenCDInferencer(
    # 注意：这里应该填写模型配置文件 .py，而不是图片路径
    model='/home/f523/disk2/nym/open-cd-main/work_dirs/paper1/k/data2/5/changeformer_mit-b1_256x256_40k_levircd.py',
    weights='/home/f523/disk2/nym/open-cd-main/work_dirs/paper1/k/data2/5/best_mIoU_epoch_80.pth',
    classes=('unchanged', 'changed'),
    palette=[[0, 0, 0], [255, 255, 255]]
)


# ==============================
# 2. 输入图像对 + 标签路径
# 格式：[A图像, B图像, Label标签]
# ==============================
image_pairs = [
    [
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/whucd_00454.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/whucd_00454.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/label/whucd_00454.png'
    ],
    [
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/whucd_00445.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/whucd_00445.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/label/whucd_00445.png'
    ],
    [
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/whucd_00318.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/whucd_00318.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/label/whucd_00318.png'
    ],
    [
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/whucd_00227.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/whucd_00227.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/label/whucd_00227.png'
    ],
    [
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/whucd_00202.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/whucd_00202.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/label/whucd_00202.png'
    ],
    [
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/A/whucd_00571.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/B/whucd_00571.png',
        '/home/f523/disk2/nym/open-cd-main/data/WHU-CD-256/label/whucd_00571.png'
    ]
]


# ==============================
# 3. 输出目录
# ==============================
final_vis_dir = 'WHU_0517/vis_results-4'
final_compare_dir = 'WHU_0517/compare_results-4'

os.makedirs(final_vis_dir, exist_ok=True)
os.makedirs(final_compare_dir, exist_ok=True)


# ==============================
# 4. 工具函数：读取二值图
# ==============================
def read_binary_mask(mask_path):
    """
    读取二值掩码。
    支持 0/255 或 0/1 格式。
    最终统一转为：
        0 = unchanged
        1 = changed
    """
    mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)

    if mask is None:
        raise FileNotFoundError(f'无法读取掩码文件: {mask_path}')

    mask = (mask > 127).astype(np.uint8)

    return mask


# ==============================
# 5. 工具函数：生成对比图
# ==============================
def generate_compare_map(pred_path, label_path, save_path):
    """
    生成预测结果与 label 的对比图。

    黑色: TN，背景预测正确
    白色: TP，变化区域预测正确
    黄色: FN，漏检，真实变化但未检测出
    蓝色: FP，误检，非变化区域但检测为变化
    """

    pred = read_binary_mask(pred_path)
    label = read_binary_mask(label_path)

    if pred.shape != label.shape:
        print(f'⚠️ 尺寸不一致，正在 resize 预测图: pred={pred.shape}, label={label.shape}')
        pred = cv2.resize(
            pred,
            (label.shape[1], label.shape[0]),
            interpolation=cv2.INTER_NEAREST
        )

    h, w = label.shape
    compare = np.zeros((h, w, 3), dtype=np.uint8)

    # TP: label=1, pred=1，白色
    tp = (label == 1) & (pred == 1)
    compare[tp] = [255, 255, 255]

    # FN: label=1, pred=0，黄色
    fn = (label == 1) & (pred == 0)
    compare[fn] = [0, 255, 255]   # OpenCV 使用 BGR，黄色为 [0,255,255]

    # FP: label=0, pred=1，蓝色
    fp = (label == 0) & (pred == 1)
    compare[fp] = [255, 0, 0]     # OpenCV 使用 BGR，蓝色为 [255,0,0]

    # TN: label=0, pred=0，黑色，默认已经是黑色

    cv2.imwrite(save_path, compare)

    # 统计信息
    tp_num = np.sum(tp)
    fn_num = np.sum(fn)
    fp_num = np.sum(fp)
    tn_num = np.sum((label == 0) & (pred == 0))

    print(f'📊 对比统计:')
    print(f'   TP 正检变化区域: {tp_num}')
    print(f'   FN 漏检变化区域: {fn_num}')
    print(f'   FP 误检变化区域: {fp_num}')
    print(f'   TN 正检背景区域: {tn_num}')

    return tp_num, fn_num, fp_num, tn_num


# ==============================
# 6. 批量推理 + 对比分析
# ==============================
for i, item in enumerate(image_pairs):
    img_a, img_b, label_path = item

    base_name = os.path.splitext(os.path.basename(img_a))[0]

    print(f'\n🔹 正在处理第 {i + 1}/{len(image_pairs)} 组：{base_name}')

    temp_out_dir = f'WHU_0517/_temp_{i}'
    os.makedirs(temp_out_dir, exist_ok=True)

    # ------------------------------
    # 执行推理
    # ------------------------------
    inferencer([[img_a, img_b]], show=False, out_dir=temp_out_dir)

    # OpenCD 默认可视化输出目录
    vis_dir = os.path.join(temp_out_dir, 'vis')

    if not os.path.exists(vis_dir):
        print(f'⚠️ 未找到 vis 结果目录：{vis_dir}')
        shutil.rmtree(temp_out_dir, ignore_errors=True)
        continue

    vis_files = os.listdir(vis_dir)

    if len(vis_files) == 0:
        print(f'⚠️ vis 目录为空：{vis_dir}')
        shutil.rmtree(temp_out_dir, ignore_errors=True)
        continue

    # ------------------------------
    # 拷贝预测结果
    # ------------------------------
    for f in vis_files:
        src = os.path.join(vis_dir, f)

        ext = os.path.splitext(f)[1] or '.png'

        pred_save_path = os.path.join(final_vis_dir, f'{base_name}{ext}')
        shutil.copy(src, pred_save_path)

        print(f'✅ 已保存预测结果: {pred_save_path}')

        # ------------------------------
        # 生成预测结果与 label 的对比图
        # ------------------------------
        compare_save_path = os.path.join(final_compare_dir, f'{base_name}_compare.png')

        generate_compare_map(
            pred_path=pred_save_path,
            label_path=label_path,
            save_path=compare_save_path
        )

        print(f'✅ 已保存对比结果: {compare_save_path}')

    # ------------------------------
    # 删除临时目录
    # ------------------------------
    shutil.rmtree(temp_out_dir, ignore_errors=True)


print(f'\n🎉 全部完成！')
print(f'预测结果保存到: {final_vis_dir}')
print(f'对比结果保存到: {final_compare_dir}')